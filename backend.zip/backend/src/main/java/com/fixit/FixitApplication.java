// backend/src/main/java/com/fixit/FixitApplication.java
package com.fixit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FixitApplication {

    public static void main(String[] args) {
        SpringApplication.run(FixitApplication.class, args);
    }
}
